from django.apps import AppConfig


class SlambookConfig(AppConfig):
    name = 'slambook'
